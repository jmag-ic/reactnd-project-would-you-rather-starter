import React, { Component } from 'react';

class NewQuestion extends Component {
  render() {
    return (
      <div>New Question</div>
    );
  }
}

export default NewQuestion;