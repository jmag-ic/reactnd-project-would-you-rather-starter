import React from 'react';

function LeaderBoard(props) {
  return (
    <div>Leaer board</div>
  );
}

export default LeaderBoard;